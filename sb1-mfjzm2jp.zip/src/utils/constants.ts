// Navigation items used across components
export const navItems = ['Home', 'About', 'Services', 'Projects', 'Contact'];