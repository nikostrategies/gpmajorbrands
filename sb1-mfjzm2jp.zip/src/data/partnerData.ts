export const partners = [
  {
    id: 'bar-burrito',
    name: 'Bar Burrito',
    logo: '/src/BarBurrito.jpg',
    website: '#'
  },
  {
    id: 'big-fresh-kitchen',
    name: 'Big Fresh Kitchen',
    logo: '/src/BIg_Fresh_Kitchen.jpg',
    website: '#'
  },
  {
    id: 'dominos',
    name: 'Dominos',
    logo: '/src/Dominos_Logo.jpg',
    website: '#'
  },
  {
    id: 'evas-original',
    name: "Eva's Original",
    logo: '/src/Evas_Orginal.jpg',
    website: '#'
  },
  {
    id: 'marble-slab',
    name: 'Marble Slab',
    logo: '/src/Marble_Slab_Logo.jpg',
    website: '#'
  }
];